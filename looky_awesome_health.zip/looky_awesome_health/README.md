# looky-awesome-health

## looky-awesome-health - project structure
- cmd/
  - main.go
- pkg/
  - healthcheck/
    - healthcheck.go
  - handlers/
    - handlers.go
- config.yaml
- go.mod
- go.sum
- README.md
  