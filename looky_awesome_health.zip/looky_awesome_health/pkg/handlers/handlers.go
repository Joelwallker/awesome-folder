package handlers

import (
	"encoding/json"
	"net/http"

	"looky_awesome_health/pkg/healthcheck"
)

func HealthHandler(config healthcheck.Config) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		groupResults := make(map[string]map[string]bool)

		for _, group := range config.Groups {
			results := make(map[string]bool)
			failedCount := 0

			for _, service := range group.Services {
				isHealthy := healthcheck.CheckHealth(service)
				results[service.Name] = isHealthy
				if !isHealthy {
					failedCount++
				}
			}

			percentage := (failedCount * 100) / len(group.Services)
			if percentage >= group.Threshold {
				w.WriteHeader(http.StatusForbidden)
				return
			}

			groupResults[group.Name] = results
		}

		response := map[string]interface{}{
			"status": "OK",
			"groups": groupResults,
		}

		jsonResp, _ := json.Marshal(response)
		w.Header().Set("Content-Type", "application/json")
		w.Write(jsonResp)
	}
}

func StatsHandler(config healthcheck.Config) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		groupResults := make(map[string]map[string]bool)

		for _, group := range config.Groups {
			results := make(map[string]bool)

			for _, service := range group.Services {
				isHealthy := healthcheck.CheckHealth(service)
				results[service.Name] = isHealthy
			}

			groupResults[group.Name] = results
		}

		response := map[string]interface{}{
			"status": "OK",
			"groups": groupResults,
		}

		jsonResp, _ := json.Marshal(response)
		w.Header().Set("Content-Type", "application/json")
		w.Write(jsonResp)
	}
}
