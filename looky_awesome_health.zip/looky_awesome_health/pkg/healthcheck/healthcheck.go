package healthcheck

import (
	"fmt"
	"net/http"
)

type Service struct {
	Name string `yaml:"name"`
	URL  string `yaml:"url"`
}

type Group struct {
	Name      string    `yaml:"name"`
	Threshold int       `yaml:"threshold"`
	Services  []Service `yaml:"services"`
}

type Config struct {
	Groups []Group `yaml:"groups"`
}

func CheckHealth(service Service) bool {
	resp, err := http.Get(service.URL)
	if err != nil || resp.StatusCode != 200 {
		fmt.Printf("Failed to check health for service %s: %v\n", service.Name, err)
		return false
	}
	return true
}
