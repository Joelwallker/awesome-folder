package main

import (
	"fmt"
	"net/http"
	"os"

	"github.com/oneclick-llc/looky-awesome-health/pkg/handlers"
	"github.com/oneclick-llc/looky-awesome-health/pkg/healthcheck"

	"gopkg.in/yaml.v2"
)

func main() {
	config := loadConfig("config.yaml")

	http.HandleFunc("/health", handlers.HealthHandler(config))
	http.HandleFunc("/stats", handlers.StatsHandler(config))

	http.ListenAndServe(":8080", nil)
}

func loadConfig(filename string) healthcheck.Config {
	config := healthcheck.Config{}
	data, err := os.ReadFile(filename)
	if err != nil {
		fmt.Println("Error reading config file:", err)
		return config
	}

	err = yaml.Unmarshal(data, &config)
	if err != nil {
		fmt.Println("Error parsing config file:", err)
	}

	return config
}
